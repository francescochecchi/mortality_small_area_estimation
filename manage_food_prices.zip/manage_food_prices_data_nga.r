#..........................................................................................
### +++++++++++++ SMALL-AREA ESTIMATION OF CRISIS-ATTRIBUTABLE MORTALITY ++++++++++++++ ###
#..........................................................................................

#..........................................................................................
## ----------------- R CODE TO MANAGE WFP FOOD PRICE DATA FROM NIGERIA ----------------- ##
#..........................................................................................

                                          # Written by Francesco Checchi, LSHTM (Apr 2021)
                                          # francesco.checchi@lshtm.ac.uk 


#..........................................................................................
### Preparatory steps
#.........................................................................................

  #...................................      
  ## Install or load required R packages

    
    # List of required packages
    x1 <- c("boot", "broom", "broom.mixed", "data.table", "flextable", "gbm", "GGally", "ggplot2", "ggpubr",
      "ggridges", "glmmTMB", "gtools", "huxtable", "jtools", "lattice", "lme4", "lmtest", "lubridate", 
      "MASS", "mice", "multiwayvcov", "officer", "performance", "pscl", "RColorBrewer", "rcompanion", 
      "readxl", "readr", "reshape2", "rlang", "sandwich", "scales", "survey", "tools", "zoo")
    
    # Install any packages not yet installed
    x2 <- x1 %in% row.names(installed.packages())
    if (any(x2 == FALSE)) { install.packages(x1[! x2]) }

    # Load all packages    
    lapply(x1, library, character.only = TRUE)
    
  #...................................      
  ## Starting setup

    # Clean up from previous code / runs
    rm(list=ls(all=TRUE) )
  
    # Set font
    windowsFonts(Arial=windowsFont("Arial"))

    # Set working directory to where this file is stored
    current_path = rstudioapi::getActiveDocumentContext()$path 
    setwd(dirname(current_path ))
    print( getwd() )
    
    # Initialise random numbers
    set.seed(123)
    
    # Colour-blind palette for graphing
    palette_cb <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")
    show_col(palette_cb)


#.........................................................................................    
### Reading in required files and parameters
#.........................................................................................
  
  #...................................      
  ## Food price dataset
  prices <- read_excel("wfp_food_prices_nigeria.xlsx", sheet = "wfp_food_prices_nigeria")
    # remove tibble
    prices <- as.data.frame(prices)

  #...................................      
  ## NGN to USD exchange rates by month and year
  exchange <- read_excel("nga_ngn_usd_exchange_historical.xlsx", sheet = "currency_rate")
    # remove tibble
    exchange <- as.data.frame(exchange)

  #...................................      
  ## USD inflation by year
  inflation <- read_excel("usd_inflation_data.xlsx", sheet = "usd_inflation_data")
    # remove tibble
    inflation <- as.data.frame(inflation)

  #...................................      
  ## Analysis strata
    # LGAs
    strata <- read_excel("nga_analysis_strata.xlsx", sheet = "strata")
      # remove tibble
      strata <- as.data.frame(strata)

    # LGAs to markets
    lgas_to_markets <- read_excel("nga_analysis_strata.xlsx", sheet = "additional_nga")
      # remove tibble
      lgas_to_markets <- as.data.frame(lgas_to_markets)

#.........................................................................................                            
### Generating time series of LGA-months and other required metadata
#.........................................................................................
  
  #...................................    
  ## Create a time series of lga-time (including burn-in/-out periods of x years before/after analysis period)

    # create a time unit variable tm (from month 1 to month T of analysis period T) 
    tm <- seq(1, (( 2021 - 2010 ) * 12 + 5 - 1 + 1 ), 1)
    
    # create a time series of lga-year-months
    ts <- expand.grid(unlist(strata[, "lga"] ), tm)
    colnames(ts) <- c("lga", "tm")
    
    # work out corresponding year and month values
    ts[, "y"] <- floor( (ts[, "tm"] - 1) / 12) + 2010
    ts[, "m"] <- ts[, "tm"] - (ts[, "y"] - 2010) * 12
    
    # merge state back in
    ts <- merge(ts, strata[, c("lga", "state")], by=c("lga"), sort=TRUE)
    
    # sort time series
    ts <- ts[order(ts[, "lga"], ts[, "tm"]), ]
  
      
  #...................................    
  ## Define lga names and time units
    # lga names
    lga_names <- as.character(unique(strata[, "lga"]))
    lga_names <- sort(lga_names)
    
    # Time units  
    t_units <- unique(ts[, c("tm", "m", "y")])
  

#.........................................................................................    
### Computing prices in 2010 USD
#.........................................................................................

  #...................................    
  ## Prepare prices dataset
    # Month and year
    prices[, "m"] <- month(prices[, "date"])
    prices[, "y"] <- year(prices[, "date"])
    
    # Remove unneeded variables and rename columns
    x1 <- c("date", "category", "country", "adm1id", "mktid", "cmid", "ptid", "umid", "catid", "sn", "default")
    prices <- prices[, ! colnames(prices) %in% x1]
    colnames(prices) <- c("commodity_name", "unit", "price", "currency", "state", "market", "m", "y")
    
    # Create additional commodity variables
    x1 <- sapply(prices$commodity_name, function(x) {x2 <- strsplit(x, " - "); return(unlist(x2)) } )
    prices[, c("commodity_name", "price_type")] <- t(x1)
    
    # Keep only commodities that are of interest
    x1 <- sort(unique(prices$commodity_name) )
    x2 <- c("Bread", "Cowpeas (white)", "Fuel (petrol-gasoline)", "Maize (white)", "Millet", "Rice (imported)",
      "Rice (local)", "Sorghum (white)")
    prices <- subset(prices, commodity_name %in% x2)
    
    # Create single commodity name
    x1 <- sort(unique(prices$commodity_name) )
    x2 <- c("bread", "cowpea_white", "fuel_petrol", "maize_white", "millet", "rice_import", "rice_local", 
      "sorghum_white")
    x1 <- cbind(x1, x2)
    colnames(x1) <- c("commodity_name", "commodity")
    prices <- merge(prices, x1, by = "commodity_name", all.x = TRUE)
    prices[, "commodity"] <- ifelse(prices[, "price_type"] == "Retail", 
      paste(prices[, "commodity"], "_retail", sep = ""), paste(prices[, "commodity"], "_whole", sep = ""))

    # Eliminate data prior to 2010 and after 2020
    prices <- subset(prices, y %in% c(2010:2020))
    
    # Standardise all Kg prices to price per 1 Kg
    table(prices$unit)
    equiv <- data.frame("unit" = sort(unique(prices$unit)), "conversion" = c(1/1.4, 1/100, 1/50, 1, 1, 1))
    prices <- merge(prices, equiv, by = "unit", all.x = TRUE)
    prices[, "price_std"] <- prices[, "price"] * prices[, "conversion"]
    
  #...................................    
  ## Compute 2010 USD prices
    
    # Merge datasets together
    prices <- merge(prices, exchange, by = c("y", "m"), all.x = TRUE)
    prices <- merge(prices, inflation, by = "y", all.x = TRUE)
    
    # Compute 2010 USD price
    prices[, "price_adj"] <- (prices[, "price_std"] / prices[, "currency_rate"]) / prices[, "usd_inflation"]


#.........................................................................................    
### Preparing BAY state dataset
#.........................................................................................

  #...................................    
  ## Select data
          
    # Select only data from BAY states
    prices_bay <- subset(prices, state %in% c("Yobe", "Adamawa", "Borno"))
    
    # Select only markets with sufficient completeness over time period
    table(prices_bay[, c("market", "y")])
    x1 <- c("Biu", "Damaturu", "Maiduguri", "Mubi", "Potiskum")
    prices_bay <- subset(prices_bay, market %in% x1)  

    # Investigate possible duplicate observations
    table(duplicated(prices_bay[, c("market", "y", "m", "commodity")]))
    x1 <- which(duplicated(prices_bay[, c("market", "y", "m", "commodity")]))
    View(prices_bay[x1, ])
      # all duplicates are from Potiskum market; but are they duplicates in terms of price as well?
      x2 <- which(duplicated(prices_bay[, c("market", "y", "m", "commodity", "price_std")]))
      View(prices_bay[x2, ])
      # no, they're not, so let's compare them
      x3 <- which(duplicated(prices_bay[, c("market", "y", "m", "commodity")], fromLast = TRUE))
      x4 <- rbind(prices_bay[x1, ], prices_bay[x3, ])
      View(x4)    
      # eliminate all 1.4 Kg observations, keep only 1 Kg
      x1 <- which(duplicated(prices_bay[, c("market", "y", "m", "commodity")]) & prices_bay[, "unit"] == "1.4 KG")
      x3 <- which(duplicated(prices_bay[, c("market", "y", "m", "commodity")], fromLast = TRUE) & prices_bay[, "unit"] == "1.4 KG")
      prices_bay <- prices_bay[-c(x1, x3), ]
      table(duplicated(prices_bay[, c("market", "y", "m", "commodity")]))
      

  #...................................    
  ## Merge markets to LGAs and write dataset
    
    # Merge markets with LGA-month time series
    ts <- merge(ts, lgas_to_markets[, c("lga", "market")], by = "lga", all.x = TRUE)
    
    # Create LGA time series for each commodity
    x1 <- unique(prices_bay$commodity)
    ts_comm <- c()
    for (i in x1) {
      ts_comm <- rbind(ts_comm, data.frame(ts, "commodity" = i))
    }

    # Merge prices with time series
    prices_bay <- merge(ts_comm, prices_bay, by = c("state", "market", "y", "m", "commodity"), all.x = TRUE)
    
    # To minimise file size, only select non-missing observations and reduce columns
    prices_bay <- subset(prices_bay, ! is.na(price_adj) )
    prices_bay <- prices_bay[, c("market", "lga", "y", "m", "commodity", "price", "price_std", "unit", 
      "currency_rate", "usd_inflation", "price_adj")]
    
  #...................................    
  ## Write
  write.csv(prices_bay, "wfp_food_prices_nigeria_bay.csv", row.names = FALSE)

#.........................................................................................    
### Preparing non-BAY state datasets
#.........................................................................................
  
  #...................................    
  ## Prepare
    # Select non-BAY states
    prices_non_bay <- subset(prices, ! state %in% c("Yobe", "Adamawa", "Borno"))
  
    # Create time series of markets, commodities and time
    ts_non_bay <- expand.grid(unique(prices_non_bay$market), unique(t_units$y), unique(t_units$m), 
      unique(prices_non_bay$commodity))
    colnames(ts_non_bay) <- c("market", "y", "m", "commodity")
    
    # Merge with prices data
    prices_non_bay <- merge(ts_non_bay, prices_non_bay, by = c("market", "y", "m", "commodity"), all.x = TRUE)
  
    # Restrict to time period of interest
    prices_non_bay <- subset(prices_non_bay, y %in% c(2010:2020) )
    
  #...................................    
  ## Write
  write.csv(prices_non_bay, "wfp_food_prices_nigeria_non_bay.csv", row.names = FALSE)
  

#.........................................................................................    
### Coming up with counterfactual trends in white maize (wholesale)
#.........................................................................................
   
  #...................................    
  ## Prepare data

    # Remove unnecessary data
    maize <- prices
    maize <- maize[, c("state", "market", "y", "m", "commodity", "unit", "price_adj")]  
    maize <- subset(maize, commodity == "maize_white_whole")
    
    # Create a market time series
    x2 <- unique(maize[, c("state", "market")])
    x1 <- expand.grid(unique(maize$market), unique(t_units$y), unique(t_units$m) )
    colnames(x1) <- c("market", "y", "m")
    x1 <- merge(x1, x2, by = "market", all.x = TRUE)
    x1 <- merge(x1, t_units, by = c("y", "m"), all.x = TRUE)
    x1 <- x1[complete.cases(x1), ]
    
    # Add market-tm units but restrict years
    maize <- merge(x1, maize, by = c("state", "market", "y", "m"), all.x = TRUE )
    maize <- subset(maize, y %in% c(2010:2020))
    maize <- maize[order(maize[, "market"], maize[, "tm"]), ]
    
    # Inspect completeness of market time series
    table(subset(maize, ! is.na (price_adj))[, c("market", "y")])
      # eliminate markets with sparse data
      x1 <- c("Aba")
      maize <- subset(maize, ! market %in% x1)      
      
    # Identify markets as BAY states or not
    maize[, "bay"] <- ifelse(maize[, "state"] %in% c("Yobe", "Adamawa", "Borno"), "BAY states", "other states" )
 
  #...................................    
  ## Smooth and plot series
       
    # For each remaining market, smooth series
    maize[, "price_smooth"] <- NA
    x1 <- sort(unique(maize$market))
    maize <- maize[order(maize[, "market"], maize[, "tm"]), ]
    
    for (i in x1) {
      # select market time series
      x2 <- maize[maize$market == i, c("tm", "price_adj")]
      
      # smooth
      x3 <- predict(smooth.spline(as.matrix(na.omit(x2) ), spar = 0.3 ), x2[, "tm"] )  
      
      # add to dataset
      maize[maize$market == i, "price_smooth"] <- x3$y
    }
        
    # Plot smoothed and unsmoothed variables, by market
    x1 <- maize[complete.cases(maize), ]
          
      # code if instead wish to plot by admin1
      # x1 <- aggregate(ts[, c(paste(x_vars[j]), paste(x_vars[j], "_smooth", sep=""))],
      #                    by = as.list(ts[, c("admin1", "y", "m", "tm")]), FUN=mean)
          
      # create a date variable for the x axis
      x1[, "date"] <- dmy(paste("1", x1[, "m"], x1[, "y"], sep="/"))
          
      # create breaks for years
      year_breaks <- subset(x1, m==1)[, "date"]
       
      # draw plot
      plot <- ggplot(x1, aes(x = date, colour = bay ) ) +
        annotate(geom = "rect", xmin = dmy("1/1/2016"), xmax = dmy("1/1/2020"), ymin = -Inf, ymax = Inf,
          fill = palette_cb[8], alpha = 0.2) +
        geom_point(aes(y = price_adj ), alpha = 0.3) +
        geom_line(aes(y = price_smooth ), size = 1, alpha = 0.5) +
         scale_y_continuous("price of 1 Kg white maize, wholesale (USD, 2010)", breaks = seq(0, 1, by = 0.1)) +
        theme_bw() + theme(plot.margin = unit(c(0.5, 0.5, 1, 0.5), "cm") ) +
        labs(x = "\nmonth") +
        geom_vline(xintercept = year_breaks, color="grey50") +
        facet_wrap(state~market, ncol = 3, scales = "free_y" ) +
        scale_x_date("year", 
          limits= c(dmy(paste("1", 1, 2010, sep="/")), dmy(paste("1", 12, 2020, sep="/"))) ,
          expand=c(0,0) , minor_breaks=NULL, date_breaks="12 months", date_labels = "%Y") +
        scale_colour_manual(values = palette_cb[c(7, 6)] ) +
        theme(plot.title = element_text(color="grey20"), legend.position = "none",
          axis.title.x = element_text(color="grey20", size = 10), 
          axis.title.y = element_text(color="grey20", size = 10), 
          axis.text.x = element_text(angle = -90, vjust=0.5) )
          
      # call and save plot
      print(plot)
      ggsave("nga_prd_sorghum_market_trends.png", height = 25, width = 25, units = "cm", dpi = "print")
 
  #...................................    
  ## Come up with counterfactuals
    
    # Counterfactual values by LGA
    counter <- unique(prices_bay[, c("lga", "market")])
    
    # First, lag variable by 3 months as per model
    x1 <- subset(maize, bay == "BAY states")
    x1 <- data.table(x1)
    x1[, "price_smooth_lag3" :=  shift(.SD, 3, fill = NA ), by = market, .SDcols = "price_smooth"]
    x1 <- as.data.frame(x1)
    
    # Restrict to Jan 2015 and up to Dec 2019, when there is enough data availability across markets
    x1 <- subset(x1, tm %in% 61:120)
    
    # Likely: no price spike, levels stay at median of pre-spike (Jan-Jun 2015) and post-spike (2018-2019) levels
    x2 <- subset(t_units, tm %in% c(61:66, 97:120) )$tm
    x3 <- subset(x1, tm %in% x2)
    x2 <- aggregate(x3[, "price_smooth_lag3"], by = list(x3$market), FUN = median, na.rm = TRUE )
    colnames(x2) <- c("market", "likely")
    counter <- merge(counter, x2, by = "market", all.x = TRUE)
    
    # Best: levels are as low as the minimum of the series
    x2 <- aggregate(x1[, "price_smooth_lag3"], by = list(x1$market), FUN = min, na.rm = TRUE )
    colnames(x2) <- c("market", "best")
    counter <- merge(counter, x2, by = "market", all.x = TRUE)    
      
    # Worst: series median
    x2 <- aggregate(x1[, "price_smooth_lag3"], by = list(x1$market), FUN = median, na.rm = TRUE )
    colnames(x2) <- c("market", "worst")
    counter <- merge(counter, x2, by = "market", all.x = TRUE)    
      
    # Write
    write.csv(counter, "nga_maize_counterfactuals.csv", row.names = FALSE)
            
#.........................................................................................
### ENDS
#.........................................................................................
      
