#..........................................................................................
### +++++++++++++ SMALL-AREA ESTIMATION OF CRISIS-ATTRIBUTABLE MORTALITY ++++++++++++++ ###
#..........................................................................................

#..........................................................................................
## ----------- R CODE TO MANAGE VTS VACCINATION COVERAGE DATA FROM NIGERIA ------------- ##
#..........................................................................................

                                          # Written by Francesco Checchi, LSHTM (Apr 2021)
                                          # francesco.checchi@lshtm.ac.uk 


#..........................................................................................
### Preparatory steps
#.........................................................................................

  #...................................      
  ## Install or load required R packages

    # List of required packages
    x1 <- c("boot", "broom", "broom.mixed", "data.table", "flextable", "gbm", "GGally", "ggplot2", "ggpubr",
      "ggridges", "glmmTMB", "gtools", "huxtable", "jtools", "lattice", "lme4", "lmtest", "lubridate", 
      "MASS", "mgcv", "mice", "multiwayvcov", "officer", "performance", "pscl", "RColorBrewer", "rcompanion", 
      "readxl", "readr", "reshape2", "rlang", "sandwich", "scales", "survey", "tools", "zoo")
    
    # Install any packages not yet installed
    x2 <- x1 %in% row.names(installed.packages())
    if (any(x2 == FALSE)) { install.packages(x1[! x2]) }

    # Load all packages    
    lapply(x1, library, character.only = TRUE)
    
  #...................................      
  ## Starting setup

    # Clean up from previous code / runs
    rm(list=ls(all=TRUE) )
  
    # Set font
    windowsFonts(Arial=windowsFont("Arial"))

    # Set working directory to where this file is stored
    current_path = rstudioapi::getActiveDocumentContext()$path 
    setwd(dirname(current_path ))
    print( getwd() )
    
    # Initialise random numbers
    set.seed(123)
    
    # Colour-blind palette for graphing
    palette_cb <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")
    show_col(palette_cb)


#.........................................................................................    
### Reading in required files and parameters
#.........................................................................................
 
  #...................................      
  ## VTS dataset 
    
    # Read dataset
    df <-read_excel("time-trend-analysis.xlsx", sheet = "Raw data", skip = 1)
    df <- as.data.frame(df)

    # Delete unneeded columns and change column names
    x1 <- c("Campaign Label", "State", "LGA", "Settlement Type", "Settlement Count",
      "Sum of Geo-Coverage Denominators in Ward", "Avgerage Geo-Coverage within Ward"  )
    df <- df[, x1]
    colnames(df) <- c("campaign", "state", "lga", "settlement_type", "settlement_count", 
      "n_geocoverage_denominators", "mean_coverage")
  
  #...................................      
  ## Analysis strata
    # LGAs
    strata <- read_excel("nga_analysis_strata.xlsx", sheet = "strata")
      # remove tibble
      strata <- as.data.frame(strata)


#.........................................................................................                            
### Generating time series of LGA-months and other required metadata
#.........................................................................................
  
  #...................................    
  ## Create a time series of lga-time (including burn-in/-out periods of x years before/after analysis period)

    # create a time unit variable tm (from month 1 to month T of analysis period T) 
    tm <- seq(1, (( 2020 - 2012 ) * 12 + 12 - 1 + 1 ), 1)
    
    # create a time series of lga-year-months
    ts <- expand.grid(unlist(strata[, "lga"] ), tm)
    colnames(ts) <- c("lga", "tm")
    
    # work out corresponding year and month values
    ts[, "y"] <- floor( (ts[, "tm"] - 1) / 12) + 2012
    ts[, "m"] <- ts[, "tm"] - (ts[, "y"] - 2012) * 12
    
    # merge state back in
    ts <- merge(ts, strata[, c("lga", "state")], by=c("lga"), sort=TRUE)
    
    # sort time series
    ts <- ts[order(ts[, "lga"], ts[, "tm"]), ]
  
      
  #...................................    
  ## Define lga names and time units
    # lga names
    lga_names <- as.character(unique(strata[, "lga"]))
    lga_names <- sort(lga_names)
    
    # Time units  
    t_units <- unique(ts[, c("tm", "m", "y")])
  
      
#.........................................................................................    
### Computing mean coverage by LGA-month
#.........................................................................................
 
  #...................................      
  ## Prepare dataset
    # Identify month and year of campaign
    df[, "m"] <- NA
    df[, "y"] <- NA
    x1 <- as.vector(df[, "campaign"]) 

    for (i in c("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec") ) {
      x2 <- grep(i, x1, value = FALSE)
      df[x2, "m"] <- i    
    } 

    for (i in paste(c(2010:2020)) ) {
      x2 <- grep(i, x1, value = FALSE)
      df[x2, "y"] <- i
    } 

    # Rows with missing month/year are from a dry-run campaign, so can delete
    df <- df[complete.cases(df[, c("y", "m")]), ]

    # Clean up dates
    df[, "date"] <- lubridate::dmy(paste("1", df$m, df$y, sep = "-") )
    df[, "m"] <- month(df$date)
    df[, "y"] <- year(df$date)  
    
  #...................................      
  ## Take weighted average of mean coverage by LGA and time: weight = 'n_geocoverage_denominators'
    # Product of values and weights
    df[, "wt_values"] <- df$n_geocoverage_denominators * df$mean_coverage
  
    # Sum of weighted values and sum of weights
    df_agg <- aggregate(df[, c("n_geocoverage_denominators", "wt_values")], 
      by = df[, c("state", "lga", "m", "y")], FUN = sum)
    
    # Weighted means
    df_agg[, "weighted_coverage"] <- df_agg$wt_values / df_agg$n_geocoverage_denominators

  #...................................      
  ## Write files for BAY states and other states

    # Clean up BAY LGAs
    table(subset(df_agg, state %in% c("Adamawa", "Borno", "Yobe"))$lga)  
    df_agg[, "lga"] <- stringr::str_to_title(df_agg[, "lga"])
    df_agg[, "lga"] <- gsub("/", " ", df_agg[, "lga"] )
    df_agg[, "lga"] <- gsub("-", " ", df_agg[, "lga"] )
    df_agg[, "lga"] <- ifelse(df_agg[, "lga"] == "Ganye", "Ganaye", df_agg[, "lga"])
    df_agg[, "lga"] <- ifelse(df_agg[, "lga"] == "Girei", "Gireri", df_agg[, "lga"])
    
    # Select
    df_bay <- subset(df_agg, state %in% c("Adamawa", "Borno", "Yobe"))  
    df_non_bay <- subset(df_agg, ! state %in% c("Adamawa", "Borno", "Yobe"))  
    
    # Write
    write.csv(df_bay[, c("lga", "y", "m", "weighted_coverage")], "nga_vts_coverage_bay.csv", row.names = FALSE)
    # write.csv(df_non_bay[, c("lga", "y", "m", "weighted_coverage")], "nga_vts_coverage_non_bay.csv", row.names = FALSE)

        
#.........................................................................................    
### Creating counterfactual values
#.........................................................................................
 
  #...................................    
  ## Prepare data

    df_cf <- df_agg

    # Create an LGA time series
    x2 <- unique(df_cf[, c("state", "lga")])
    x1 <- expand.grid(unique(df_cf$lga), c(min(df_cf$y, na.rm = TRUE):max(df_cf$y, na.rm = TRUE)), 
      c(1:12) )
    colnames(x1) <- c("lga", "y", "m")
    x1 <- merge(x1, x2, by = "lga", all.x = TRUE)
    x1 <- merge(x1, t_units, by = c("y", "m"), all.x = TRUE)
    x1 <- x1[complete.cases(x1), ]
    
    # Add LGA-tm units
    df_cf <- merge(x1, df_cf, by = c("state", "lga", "y", "m"), all.x = TRUE )
    df_cf <- df_cf[order(df_cf[, "lga"], df_cf[, "tm"]), ]
    
    # Inspect completeness of LGA time series
    x1 <- table(subset(df_cf, ! is.na (weighted_coverage))[, c("lga", "y")])
    x1 <- reshape::cast(as.data.frame(x1), lga ~ y)
      # eliminate LGAs that don't have at least 4 observations
      x2 <- x1
      x2[, "n_obs"] <- rowSums(x2[, paste(c(2012:2020))])
      x2[, "complete"] <- ifelse(x2[, "n_obs"] >= 4, TRUE, FALSE)
      x3 <- subset(x2, complete == TRUE)$lga
      df_cf <- subset(df_cf, lga %in% x3) 
      
    # Classify BAY and non-BAY states
    df_cf[, "bay"] <- ifelse(df_cf[, "state"] %in% c("Adamawa", "Borno", "Yobe"), "BAY states", "other states")

    # Normalise weights
    df_cf[, "wt"] <- df_cf[, "n_geocoverage_denominators"] / max(df_cf[, "n_geocoverage_denominators"], na.rm = TRUE)  
      
  
  #...................................    
  ## Smooth and plot series (this step is only for visual inspection)
       
    # For each remaining LGA, smooth series
    df_cf[, "vc_smooth"] <- NA
    x1 <- sort(unique(df_cf$lga))
    df_cf <- df_cf[order(df_cf[, "lga"], df_cf[, "tm"]), ]
    
    for (i in x1) {
      # select LGA time series
      x2 <- df_cf[df_cf$lga == i, c("tm", "weighted_coverage")]
      
      # smooth
      x3 <- predict(smooth.spline(as.matrix(na.omit(x2) ), spar = 0.3 ), x2[, "tm"] , w = na.omit(x2)$wt )  
      
      # add to dataset
      df_cf[df_cf$lga == i, "vc_smooth"] <- x3$y
    }
        
    # Plot smoothed and unsmoothed variables, by LGA
    x1 <- df_cf[complete.cases(df_cf), ]
          
      # create a date variable for the x axis
      x1[, "date"] <- dmy(paste("1", x1[, "m"], x1[, "y"], sep="/"))
          
      # create breaks for years
      year_breaks <- subset(x1, m==1)[, "date"]
       
      # draw plot
      plot <- ggplot(x1, aes(x = date, colour = bay, group = lga ) ) +
        geom_point(aes(y = weighted_coverage), alpha = 0.3) +
        geom_line(aes(y = vc_smooth ), size = 1, alpha = 0.5) +
         scale_y_continuous("vaccination coverage", breaks = seq(0, 100, by = 10)) +
        theme_bw() + theme(plot.margin = unit(c(0.5, 0.5, 1, 0.5), "cm") ) +
        labs(x = "\nmonth") +
        geom_vline(xintercept = year_breaks, color="grey50") +
        #facet_wrap(state~LGA, ncol = 3, scales = "free_y" ) +
        scale_x_date("month-year", 
          limits= c(dmy(paste("1", 1, 2016, sep="/")), dmy(paste("1", 12, 2020, sep="/"))) ,
          expand=c(0,0) , minor_breaks=NULL, date_breaks="6 months", date_labels = "%b-%Y") +
        scale_colour_manual(values = palette_cb[c(7, 6)] ) +
        theme(plot.title = element_text(color="grey20"), legend.position = "none",
          axis.title.x = element_text(color="grey20", size = 10), 
          axis.title.y = element_text(color="grey20", size = 10), 
          axis.text.x = element_text(angle = -90, vjust=0.5) )
          
      # call and save plot
      print(plot)
      # ggsave("nga_prd_vc_lga_trends.png", height = 25, width = 25, units = "cm", dpi = "print")
 
  #...................................    
  ## Model evolution of vaccine coverage in both BAY and non-BAY states
      
    # Fit a GAMM model to the non-BAY data (coverage as function of time, random effect = time nested within LGA)
     # select data
      non_bay <- subset(df_cf, bay == "other states")
      x1 <- non_bay[complete.cases(non_bay[, c("lga", "tm", "weighted_coverage", "wt")]), ]
      x1[, "lga"] <- factor(x1[, "lga"])
      
      # fit model
      fit <- gam(weighted_coverage ~ s(tm) + s(lga, tm, bs = "re"), family = "gaussian", data = x1, weights = wt )      
      summary(fit)
    
    # Predict to all time points and aggregate by tm
      
      # predict to all time points, generate 95%CIs
      non_bay[, c("pred", "pred_se")] <- predict(fit, newdata = non_bay, se.fit = TRUE)
      non_bay[, "pred_lci"] <- non_bay[, "pred"] - 1.96 * non_bay[, "pred_se"]
      non_bay[, "pred_uci"] <- non_bay[, "pred"] + 1.96 * non_bay[, "pred_se"]
      
      # aggregate to compute mean across all NGAs, by BAY vs non-BAY
      non_bay <- aggregate(non_bay[, c("pred", "pred_lci", "pred_uci")], 
        by = list(tm = non_bay$tm), FUN = mean, na.rm = TRUE)
      non_bay[, "bay"] <- "other states"
      
    # Fit a GAMM model to the BAY data (coverage as function of time, random effect = time nested within LGA)
     # select data
      bay <- subset(df_cf, bay == "BAY states")
      x1 <- bay[complete.cases(bay[, c("lga", "tm", "weighted_coverage", "wt")]), ]
      x1[, "lga"] <- factor(x1[, "lga"])
      
      # fit model
      fit <- gam(weighted_coverage ~ s(tm) + s(lga, tm, bs = "re"), family = "gaussian", data = x1, weights = wt )      
      summary(fit)
    
    # Predict to all time points and aggregate by tm
      
      # predict to all time points, generate 95%CIs
      bay[, c("pred", "pred_se")] <- predict(fit, newdata = bay, se.fit = TRUE)
      bay[, "pred_lci"] <- bay[, "pred"] - 1.96 * bay[, "pred_se"]
      bay[, "pred_uci"] <- bay[, "pred"] + 1.96 * bay[, "pred_se"]
      
      # aggregate to compute mean across all NGAs, by BAY vs non-BAY
      bay <- aggregate(bay[, c("pred", "pred_lci", "pred_uci")], 
        by = list(tm = bay$tm), FUN = mean, na.rm = TRUE)
      bay[, "bay"] <- "Adamawa, Borno and Yobe"
      
    # Combine BAY and non-BAY and plot both
      
      all <- rbind(non_bay, bay)
      
      # add time units, restrict to analysis period and create date
      all <- merge(all, t_units, by = "tm", all.x = TRUE)
      all <- subset(all, y %in% c(2016:2019))
      all[, "date"] <- dmy(paste("1", all[, "m"], all[, "y"], sep="/"))
      
      # plot GAM predictions and smoothed values, by BAY vs. non BAY states
      plot <- ggplot(all, aes(x = date, group = bay, colour = bay, fill = bay)) +
        geom_line(aes(y = pred ), size = 1, alpha = 0.3) +
        geom_ribbon(aes(ymin = pred_lci, ymax = pred_uci), alpha = 0.3, colour = NA) +
        scale_colour_manual(values = palette_cb[c(7,4)]) +
        scale_fill_manual(values = palette_cb[c(7,4)]) +
        scale_y_continuous("predicted vaccination geocoverage (%)", minor_breaks = NULL, 
          breaks = seq(40, 100, by = 10), limits = c(40, 100) ) +
        theme_bw() +
        guides(colour = FALSE) +
        theme(legend.position="bottom", legend.direction="horizontal") +
        scale_x_date("", minor_breaks = NULL, date_breaks = "6 months", date_labels = "%b-%Y", expand = c(0,0),
          limits = c(dmy("1/1/2016"), dmy("31/12/2019") ) ) +
          labs(fill = "") +
        theme(legend.title = element_text(color="grey20", size=11),
          legend.text = element_text(color="grey20", size=11),
          axis.title.x = element_text(color="grey20", size=11), 
          axis.text.x = element_text(color = "grey20", size=10, angle=315, hjust=0, vjust=0),               
          axis.line.y = element_line(color = "grey20"),
          axis.ticks.y = element_line(color = "grey20"),
          axis.text.y = element_text(color = "grey20", size=11),
          axis.title.y = element_text(color="grey20", margin = margin(r = 10), size=11 ),
          plot.margin = unit(c(0.5,2,0.5,0.5), "cm")
        )
      
      plot
      ggsave("nga_prd_vc_counter_trends.png", height = 12, width = 18, units = "cm", dpi = "print")
      

    # Counterfactual values by month, based on non-BAY states - estimate = likely, 95%CIs = worst and best
    counter <- all
    counter <- subset(counter, bay == "other states")
    counter <- counter[, c("pred", "pred_lci", "pred_uci", "m", "y")]
    colnames(counter) <- c("likely", "worst", "best", "m", "y")
    
    # Write
    write.csv(counter, "nga_vaccination_coverage_counterfactuals.csv", row.names = FALSE)
            
#.........................................................................................
### ENDS
#.........................................................................................
      
    